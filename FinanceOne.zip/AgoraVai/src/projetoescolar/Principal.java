package projetoescolar;

import javax.swing.UIManager;

public class Principal {

    
    
    
    


    public static void main(String[] args) {
        
        
        
        LoginPagina teste = new LoginPagina();
        teste.setVisible(true);








    }
    
}
